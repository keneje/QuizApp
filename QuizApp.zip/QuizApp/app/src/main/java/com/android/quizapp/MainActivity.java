package com.android.quizapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int score=0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout1);



        String string= getString(R.string.option1);

        Button next = findViewById(R.id.next);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View q1 = findViewById(R.id.Q1);
                q1.setVisibility(View.GONE);
                View q2 = findViewById(R.id.Q2);
                q2.setVisibility(View.GONE);
                View q3 = findViewById(R.id.Q3);
                q3.setVisibility(View.VISIBLE);
                View q4 = findViewById(R.id.Q4);
                q4.setVisibility(View.VISIBLE);
                View q5= findViewById(R.id.Q5);
                q5.setVisibility(View.VISIBLE);
            }

        });


    }
    public void openApp(View view){
        setContentView(R.layout.activity_main);
    }

    private void advice(int score) {
        TextView getAdvice = (TextView) findViewById(R.id.advice);
        String myAdvice = "";

        if (score == 100) {
            myAdvice = "Superb! You must be a champion" \n;
        }
        else if(score > 75 && score < 100) {
            myAdvice = "You Almost score 100%" \n ;

        }
        else if (score >= 50 && score < 70) {
            myAdvice = "You know so much about Nigeria " + \n ;

        }
        else if (score < 45) {
            myAdvice = " Hmmm are you a foreigner?" + \n ;

        }

        getAdvice.setText(myAdvice);
    }

    public void submitAnswers(View view) {
        RadioButton radioButton1 = (RadioButton) findViewById(R.id.q1_answer);
        boolean r1= radioButton1.isChecked();

        RadioButton radioButton2 = (RadioButton) findViewById(R.id.q2_answer);
        boolean r2= radioButton2.isChecked();

        RadioButton radioButton3 = (RadioButton) findViewById(R.id.q3_answer);
        boolean r3= radioButton3.isChecked();

        RadioButton radioButton4 = (RadioButton) findViewById(R.id.q4_answer);
        boolean r4= radioButton4.isChecked();

        RadioButton radioButton5 = (RadioButton) findViewById(R.id.q5_answer);
        boolean r4= radioButton5.isChecked();


        setContentView(R.layout.result);


        score(r1,r2,r3,r4,r5);
        if(score==100) {
            Button correction = findViewById(R.id.correction);
            correction.setText("Return to quiz");

        }
        advice(score);
    }

    public void q1_radioButton(boolean radio){

        if(radio) {
            setContentView(R.layout.result);

        } else {
            TextView text= new TextView(this);
            text.setText("hello");
            setContentView(text);
        }

    }



    private void score(boolean r1, boolean r2, boolean r3, boolean r4, boolean r5 ){
        TextView finalScore= (TextView) findViewById(R.id.score);

        if(r1) {
            score += 25;

        } else {
            score += 0 ;

        }
        if (r2) {
            score += 25;
        } else {

            score += 0;
        }
        if (r3) {
            score += 25;
        } else {

            score += 0;
        }
        if (r4) {
            score += 25;
        } else {

            score += 0;
        }
        if(r5) {
            score += 25;

        } else {
            score += 0 ;

        }
        String myScore = score+ "%";
        finalScore.setText(myScore);

    }

    public void submitCorrection(View view) {
        if (score<100){
            Intent intent = new Intent(this, Result.class);
            startActivity(intent);
        } else {
            setContentView(R.layout.activity_main);
            score=0;
        }
    }

}

